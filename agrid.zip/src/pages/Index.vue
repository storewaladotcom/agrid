<template>
<div> 
   <grid-layout
            :layout.sync="layout"
            :col-num="12" 
            :is-draggable="true"
            :is-resizable="true"
            :is-mirrored="false"
            :vertical-compact="true"
            :margin="[5,5]"
            :use-css-transforms="true"
    >

        <grid-item v-for="item in layout"
                   :x="item.x"
                   :y="item.y"
                   :w="item.w"
                   :h="item.h"
                   :i="item.i"
                   :key="item.i">
             
            
            
          <q-layout   container >
      <q-header >
        <q-bar class="bg-black text-white">
          <q-icon name="menu" />
          <div>{{item.title}}</div>

          <q-space />

          <q-btn dense flat icon="minimize" />
          <q-btn dense flat icon="crop_square" />
          <q-btn dense flat icon="close" />
          <q-btn dense flat icon="push_pin" />
        </q-bar>

         <q-tabs  
        v-model="item.tab"
        dense
        no-caps
        inline-label
        class="bg-purple text-white shadow-2" v-if="item.i == '0'"
      >
        <q-tab name="mails" icon="mail" label="Mails" />
        <q-tab name="alarms" icon="alarm" label="Alarms" />
        <q-tab name="movies" icon="movie" label="Movies" />
      </q-tabs>


        <div class="q-pa-sm q-pl-md row items-center" v-if="item.i == '1'">
          <div class="cursor-pointer non-selectable">
            File
            <q-menu>
              <q-list dense style="min-width: 100px">
                <q-item clickable v-close-popup>
                  <q-item-section>Open...</q-item-section>
                </q-item>
                <q-item clickable v-close-popup>
                  <q-item-section>New</q-item-section>
                </q-item>

                <q-separator />

                <q-item clickable>
                  <q-item-section>Preferences</q-item-section>
                  <q-item-section side>
                    <q-icon name="keyboard_arrow_right" />
                  </q-item-section>

                  <q-menu anchor="top end" self="top start">
                    <q-list>
                      <q-item
                        v-for="n in 3"
                        :key="n"
                        dense
                        clickable
                      >
                        <q-item-section>Submenu Label</q-item-section>
                        <q-item-section side>
                          <q-icon name="keyboard_arrow_right" />
                        </q-item-section>
                        <q-menu auto-close anchor="top end" self="top start">
                          <q-list>
                            <q-item
                              v-for="n in 3"
                              :key="n"
                              dense
                              clickable
                            >
                              <q-item-section>3rd level Label</q-item-section>
                            </q-item>
                          </q-list>
                        </q-menu>
                      </q-item>
                    </q-list>
                  </q-menu>
                </q-item>

                <q-separator />

                <q-item clickable v-close-popup>
                  <q-item-section>Quit</q-item-section>
                </q-item>
              </q-list>
            </q-menu>
          </div>

          <div class="q-ml-md cursor-pointer non-selectable">
            Edit
            <q-menu auto-close>
              <q-list dense style="min-width: 100px">
                <q-item clickable>
                  <q-item-section>Cut</q-item-section>
                </q-item>
                <q-item clickable>
                  <q-item-section>Copy</q-item-section>
                </q-item>
                <q-item clickable>
                  <q-item-section>Paste</q-item-section>
                </q-item>
                <q-separator />
                <q-item clickable>
                  <q-item-section>Select All</q-item-section>
                </q-item>
              </q-list>
            </q-menu>
          </div>
        </div>
      </q-header>


      <div v-if="item.i == '1'">
          <br/><br/><br/>ads
         <keep-alive>
          <component v-bind:is="'HelloShell'" ></component>
        </keep-alive>
        </div>

      {{item.i}}
    </q-layout>
     
        </grid-item>
    </grid-layout>
    </div>
</template>

<script>
 import VueGridLayout from 'vue-grid-layout';
import vue from 'vue'
export default {
  name: 'PageIndex',
  components: {
           GridLayout: VueGridLayout.GridLayout,
           GridItem: VueGridLayout.GridItem 
       },
       data () { 
         return {
           window: window,
	        layout: [
                {
                  "x":0,"y":0,"w":2,"h":2,"i":"0", "title": "Q/A Search", "tab": null},
                {"x":2,"y":0,"w":2,"h":4,"i":"1", "title": "Phone Book"},
                 {"x":2,"y":3,"w":2,"h":4,"i":"2", "title": "Virtual Assistant"},
            ],
            
	    }
       },
    mounted(){
       
    }
}
</script>
<style>

.absolute-full{
  right: 0px !important;
} 

.vue-grid-item.vue-grid-placeholder {
    background: blue !important;
    border:1px solid #000;
}

.vue-grid-item:not(.vue-grid-placeholder) {
    background: #fff;
    border: 1px solid #ccc;
}
</style>