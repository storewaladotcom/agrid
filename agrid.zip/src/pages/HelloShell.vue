<template>
        <hello-mini-app v-if="show"></hello-mini-app>
</template>
<script>

import ExternalComponent from '../components/ExternalComponent';

const HelloMiniApp = () => ExternalComponent('http://localhost:8200/Hello.umd.min.js');

export default {
    name: 'HelloShell',
    components: { 
        HelloMiniApp
    },
    data(){
        return {
            show:false
        }
    },
    mounted(){
        setTimeout(() => {
            this.show = true
        }, 5000);
    }

}
</script>